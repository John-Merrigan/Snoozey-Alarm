//
//  WakeUpViewController.swift
//  Snooze Alarm 0.0
//
//  Created by John Merrigan on 2/15/18.
//  Copyright © 2018 John Merrigan. All rights reserved.
//

import UIKit

class WakeUpViewController: UIViewController {


    @IBOutlet weak var snoozeNumLabel: UILabel!
    @IBOutlet weak var outOfSnoozesLabel: UILabel!
    @IBOutlet weak var wakeUpLabel: UILabel!
    @IBOutlet weak var snoozeRemainingTodayLabel: UILabel!
    
    @IBOutlet weak var snoozeAgainButton: UIButton!
    @IBOutlet weak var imUpButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("wake up view controller loaded")

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
