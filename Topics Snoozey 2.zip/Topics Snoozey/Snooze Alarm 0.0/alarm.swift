//
//  Alarm.swift
//  Snooze Alarm 0.0
//
//  Created by John Merrigan on 1/11/18.
//  Copyright © 2018 John Merrigan. All rights reserved.
//  Code Frame for notifications from: https://cocoacasts.com/local-notifications-with-the-user-notifications-framework

import Foundation
import UserNotifications


//gets stock Apple Sounds
import AVFoundation

import UIKit
import EventKit

//snooze alarm is subclass of Apple's EKAlarm
struct Alarm{

    //independant of snooze credits
    var snoozeOn = false
    
    //hour and min will be supplied by alarm setter
    var timeAlarmWillSound = Date()
    
    //determines if alarm is set to ring
    var isSet = true
    
    //call to specific chime sound in apple lib
    var alarmChimeNoise: SystemSoundID = 1304
    
    var numSnoozedToday = 0
    
}
