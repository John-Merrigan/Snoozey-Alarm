//
//  AddEditAlarmTableViewController.swift
//  Snooze Alarm 0.0
//
//  Created by John Merrigan on 1/16/18.
//  Copyright © 2018 John Merrigan. All rights reserved.
//

import UIKit

class AddEditAlarmViewController: UIViewController {

    @IBOutlet weak var alarmTimePicker: UIDatePicker!

    
    
    var alarm: Alarm?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("Add Edit Alarm VC Loaded")
        
       // if let alarm = Alarm{
            
        

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
        
        guard segue.identifier == "saveUnwind" else { return }
        
        let timeAlarmWillSound = alarmTimePicker.date
        alarm = Alarm()
    }

    

    
    @IBAction func okayButtonPressed(_ sender: Any) {
    }

}
