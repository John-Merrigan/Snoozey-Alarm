//
//  ViewController.swift
//  Snooze Alarm 0.0
//
//  Created by John Merrigan on 1/8/18.
//  Copyright © 2018 John Merrigan. All rights reserved.
//

import UIKit

class AlarmTableViewController: UITableViewController {

    var alarms:[Alarm] = []
    var activeAlarmArray:[Alarm] = []
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return alarms.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "AlarmCell", for: indexPath) as! AlarmTableViewCell
        
        let alarm = alarms[indexPath.row]
        
        cell.update(with: alarm)
        cell.showsReorderControl = true
        
        return cell
    }
   
    override func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCellEditingStyle {
        return .delete
    }

    
    func refreshControlActivated(sender: UIRefreshControl) {
        tableView.reloadData()
        sender.endRefreshing()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
         print("Alarm Table VC Loaded")
        
        tableView.rowHeight = UITableViewAutomaticDimension
        tableView.estimatedRowHeight = 50.0
        
        self.refreshControl = UIRefreshControl()
        self.refreshControl?.addTarget(self, action: #selector(refreshControlActivated(sender:)), for: .valueChanged)
    
    }
    
    @IBAction func unwindToAlarmTableView(segue: UIStoryboardSegue) {
        guard segue.identifier == "saveUnwind" else { return }
        let sourceViewController = segue.source as! AddEditAlarmViewController
        
        if let alarm = sourceViewController.alarm {
            if let selectedIndexPath = tableView.indexPathForSelectedRow {
                alarms[selectedIndexPath.row] = alarm
                tableView.reloadRows(at: [selectedIndexPath], with: .none)
            } else {
                let newIndexPath = IndexPath(row: alarms.count, section: 0)
                alarms.append(alarm)
                tableView.insertRows(at: [newIndexPath], with: .automatic)
            }
        }
    }
    
    
    //creates array of active alarms. 
    //should be called whenever alarm is added or edited.
    func createActiveAlarmArray() -> [Alarm]{
       
        for individualAlarm in alarms
        {
            if(individualAlarm.isSet){
                activeAlarmArray.append(individualAlarm)
            }
        }
        
        return activeAlarmArray
    }
 
}
