//
//  alarmTableViewCell.swift
//  Snooze Alarm 0.0
//
//  Created by John Merrigan on 1/9/18.
//  Copyright © 2018 John Merrigan. All rights reserved.
//

import UIKit

class AlarmTableViewCell: UITableViewCell {
    
    let dateFormatter = DateFormatter()

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    @IBOutlet weak var alarmLabel: UILabel!
    @IBOutlet weak var alarmSwitch: UISwitch!
    
    func update(with alarm: Alarm){
        
        //Put this to original init to save memory
        dateFormatter.dateStyle = .none
        dateFormatter.timeStyle = .short
        
        
        
        alarmLabel.text = dateFormatter.string(from: alarm.timeAlarmWillSound)
        alarmSwitch.isOn = alarm.alarmSet
    
    }
    
   
    //TODO
    //if an alarm's switch is set to on, snooze is on for that alarm.


}
