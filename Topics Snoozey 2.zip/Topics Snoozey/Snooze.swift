//
//  Snooze.swift
//  Snooze Alarm 0.0
//
//  Created by John Merrigan on 1/12/18.
//  Copyright © 2018 John Merrigan. All rights reserved.
//

import Foundation


struct Snooze{
    
    //monetary penalty for snoozing
    var costOfSnoozeInCents: Double
    
    //total Purchased Snoozes
    var numSnoozesRemainingTotal : Int
    
    //total Snoozes allowed perDay
    var numSnoozesAllowedToday : Int
    
    
    //total time a snooze will last
    var lengthOfSnoozeInMinutes : Int
    

    
    init(costOfSnoozeInCents: Double, numSnoozesAllowedToday: Int, numSnoozesRemainingTotal: Int, lengthOfSnoozeInMinutes: Int) {
        
        self.costOfSnoozeInCents = costOfSnoozeInCents
        self.numSnoozesRemainingTotal = numSnoozesRemainingTotal
        self.lengthOfSnoozeInMinutes = lengthOfSnoozeInMinutes
        self.numSnoozesAllowedToday = numSnoozesAllowedToday
        
    }
}
