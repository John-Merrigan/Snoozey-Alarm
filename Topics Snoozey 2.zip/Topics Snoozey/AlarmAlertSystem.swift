//
//  AlarmAlertSystem.swift
//  Snooze Alarm 0.0
//
//  Created by John Merrigan on 3/1/18.
//  Copyright © 2018 John Merrigan. All rights reserved.
//

import Foundation
import UserNotifications


//gets stock Apple Sounds
import AVFoundation

import UIKit
import EventKit


class AlarmAlertSystem{
    
    
    //this needs to only be called if there is an alarm set
    func alarmSounds(){
        return(AudioServicesPlaySystemSound((activeAlarmArray.alarmChimeNoise)))
    }
    
    
    private func setAlarm() {
        // Create Notification Content
        let alarmSoundedLabels = UNMutableNotificationContent()
        
        // Configure Notification Content
       // alarmSoundedLabels.title = "\(timeAlarmWillSound) + alarm"
        alarmSoundedLabels.subtitle = ""
        alarmSoundedLabels.body = "Tap Button Below to Set Another Snooze"
        
        
        // Add Trigger
        //repeats needs to be changed with snooze
        let alarmSounds = UNTimeIntervalNotificationTrigger(timeInterval: 8.0, repeats: false)
        
        // Create Notification Request
        let notificationRequest = UNNotificationRequest(identifier: "Alarm Sounded", content: alarmSoundedLabels, trigger: alarmSounds)
        
        // Add Request to User Notification Center
        UNUserNotificationCenter.current().add(notificationRequest) { (error) in
            if let error = error {
                print("Wouldn't have access to Notification Request (\(error), \(error.localizedDescription))")
            }
        }
    }
    
    static func loadSampleAlarms() -> [Alarm]
    {
        return [Alarm()]
    }

}
